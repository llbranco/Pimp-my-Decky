CUE-GDI-ISO to CHD - Compresses either disc format to CHD (V5). (Will search all sub-folders and make CHDs in folder this is used in with CHDMAN.

Extract CHD to CUE - Decompresses CHD (V5) to CUE. (CUE is used by CD-based games. On the Raspberry Pi, CHD is supported by TurboGrafx-CD/PC Engine CD, Sega CD/Mega CD, and Dreamcast)

Extract CHD to GDI - Decompresses CHD (V5) to GDI. (GDI is used by Dreamcast.)

